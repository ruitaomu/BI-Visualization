# Installing Phusion Passenger

Please read README.md for installation instructions.

If you're having trouble installing Phusion Passenger, please refer to [the manual](http://www.modrails.com/documentation/Users%20guide.html).

Documentation and support resources are also available on [the website](https://www.phusionpassenger.com/documentation_and_support).
